exports.render = function(req, res) {
    res.render('services', {
        pageName: 'Services'
    })
}