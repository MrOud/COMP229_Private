exports.render = function(req, res) {
    res.render('projects', {
        pageName: 'Projects'
    })
}