exports.render = function(req, res) {
    res.render('index', {
        pageName: 'Home'
    })
}